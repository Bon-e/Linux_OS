

                    ## oshell -Operating System Project

#Project Overview

OShell is a simple Unix-like command-line shell implemented in C as part of an Operating Systems 
course project.The shell supports interactive execution, batch execution, built-in commands, 
environment variable expansion, redirection, and command operators as specified in the project PDF.

#This project demostrates core OS concepts such as:
             - Process creation and execution
             - File descriptor manipulation
             - Signal handling
             - Environment variables
             - Command parsing and execution

#TheProject Structure is looks like:

Osh/
|
|--include/
|   |-oshell.h
|
|--src/
|   |-main.c
|   |-parser.c
|   |-executor.c
|   |-builtins.c
|   |-path.c
|   |-utils.c
|   |_alias.c
|
|--man/
|   |-cd.1
|   |-exit.1
|   |-env.1
|   |-setenv.1
|   |-unsetenv.1
|   |-alias.1
|   |_path.1
|
|--to_check.txt
|--Makefile
|__readme.txt

#Compilation Instructions

Requirements:
             - Linux environment
             - GCC compiler
             - Make utility

To compile the project use the 'make' command, it is from the project root directory;
'oshell' command generates the executable files;
'make clean' is used to clean the compiled files;

# To run the shell directly: './oshell'--> Interactive mode
- then you will see the prompt:'$'
    example: echo hello
             exit

# Execute commands from the file: './oshell <file name>' -->Batch mode
-Each line in the file is executed sequentially;

#pipe / Non-interactive mode
-example: echo "echo test" | ./oshell

#Built-in commands:

#cd[dir]
- Change the current directory
- Supports: cd, cd -, cd --

#exit [status]
- Exit the shell with optional status

#env
- Print all environment variables

#setenv NAME VALUE
- Set an environment variable

#unsetenv NAME
- Remove an environment variable

#alias name=value
- Define or list command aliases

#path [dir ...]
- Set the command search path
- Replaces the existing path list

##Supported Operations

;    Sequential execution  
&&   Execute next command if previous succeeds  
||   Execute next command if previous fails  
&    Parallel execution 

Examples:
         echo one ; echo two
         true && echo success
         false || echo failed
         sleep 2 & echo done
## Out-put Redirection

Redirect standard output and standard error:
echo hello > out.txt
ls nofile > err.txt
Only one redirection per command is allowed.

## Environment Variable Expansion

Supported expansions:
$VAR   Environment variable
$?     Exit status of last command
$$     Process ID of the shell

Examples:
         echo $HOME
         echo $?
         echo $$
## Error Handling

All errors produce the unified message:
'An error has occurred'

The shell continues running after errors.

## PATH Handling

- Default path is /bin
- The path command replaces the entire path list
- If the path list is empty, external commands cannot be executed

Example:
         path
         ls          (error)
         path /bin
         ls          (works)

## Signal Handling

Ctrl + C : Ignored (shell continues running)  
Ctrl + D : Exits the shell  

## Manual Pages

Manual pages for built-in commands are located in the man directory.

Example:
        man ./man/cd.1

## Project Status

- Fully implemented according to the project Instructions
- Compiles without warnings
- All required features supported


##================== THANK YOU ========================##
























































































